-

Sujet : Intégrer une page web en html/css adaptable au différentes devices à partir d'une maquette.

Restrictions : Utilisation des flexbox & media queries, au moins 3 'commit' avec un message clair correspondant aux ajouts/modifications effectuer.

Rendu : Un lien vers un repository Github (envoyer en message privé sur discord)

+

Bonus1 : Implémentation de bootstrap pour le menu de navigation (pour nottament faire fonctionner notre burger menu)
Bonus2 : Implémenter un slider bootstrap pour remplacer ce header bleu si moche

++ 

Compétence(s) abordée(s) : Intégration statique et adaptable

